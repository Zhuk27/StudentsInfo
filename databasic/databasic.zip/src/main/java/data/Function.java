package data;

import java.sql.*;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Scanner;



public class Function {


    public static void printStudent(ResultSet resultSet) throws SQLException {

        int countStudent = 0;
        while(resultSet.next()){
            User user = new User();
            user.setId(resultSet.getInt(1));
            user.setFIO(resultSet.getString(2));
            user.setDateOfBirth(resultSet.getDate(3));
            user.setTest1(resultSet.getString(4));
            user.setDateTest1(resultSet.getDate(5));
            user.setTest2(resultSet.getString(6));
            user.setDateTest2(resultSet.getDate(7));
            user.setTest3(resultSet.getString(8));
            user.setDateTest3(resultSet.getDate(9));
            user.setTest4(resultSet.getString(10));
            user.setDateTest4(resultSet.getDate(11));
            user.setTest5(resultSet.getString(12));
            user.setDateTest5(resultSet.getDate(13));
            user.setTest6(resultSet.getString(14));
            user.setDateTest6(resultSet.getDate(15));
            user.setTest7(resultSet.getString(16));
            user.setDateTest7(resultSet.getDate(17));
            user.setTest8(resultSet.getString(18));
            user.setDateTest8(resultSet.getDate(19));
            user.setTest9(resultSet.getString(20));
            user.setDateTest9(resultSet.getDate(21));
            user.setTest10(resultSet.getString(22));
            user.setDateTest10(resultSet.getDate(23));
            user.setExam1(resultSet.getInt(24));
            user.setDateExam1(resultSet.getDate(25));
            user.setExam2(resultSet.getInt(26));
            user.setDateExam2(resultSet.getDate(27));
            user.setExam3(resultSet.getInt(28));
            user.setDateExam3(resultSet.getDate(29));
            user.setExam4(resultSet.getInt(30));
            user.setDateExam4(resultSet.getDate(31));
            user.setExam5(resultSet.getInt(32));
            user.setDateExam5(resultSet.getDate(33));

            System.out.println(user);
        }
    }
    //вывод всей базы данных
    public static void printBase(DBWorker worker){
        String query = "select * from users;";
        try  {
            Statement statement = worker.getConnection().createStatement();
            ResultSet resultSet = statement.executeQuery(query);
            Function.printStudent(resultSet);

        }catch (SQLException e){
            e.printStackTrace();
        }
    }

    //добавление студента в базу
    public static void addStudent(DBWorker worker){
        Scanner scanner = new Scanner(System.in);

        String insert = "INSERT into users ( FIO, dateOfBirth, test1, dateTest1, test2, dateTest2, test3, dateTest3, test4, dateTest4, test5, dateTest5, test6, dateTest6, test7, dateTest7, test8, dateTest8, test9, dateTest9, test10, dateTest10, exam1, dateExam1, exam2, dateExam2, exam3, dateExam3, exam4, dateExam4, exam5, dateExam5) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        try {
            PreparedStatement preparedStatement = null;
            preparedStatement = worker.getConnection().prepareStatement(insert);

            System.out.println("Введите фио студента");
            String FIO = scanner.nextLine();
            preparedStatement.setString(1, FIO);

            System.out.println("Введите дату рождения в таком формате ГГГГ-ММ-ДД");
            String dateOfBirth = scanner.nextLine();
            preparedStatement.setString(2, dateOfBirth);

            String[] test = new String[10];
            Date[] dateTest = new Date[10];
            int chetchik = 3;

            for (int i = 0; i < 10; i++){
                System.out.println("Если " + (i+1) + " зачёт сдан введите + если нет введите -");
                test[i] = scanner.nextLine();
                preparedStatement.setString(chetchik, test[i]);
                chetchik++;

                System.out.println("Введите дату " + (i+1) + " зачёта в таком формате ГГГГ-ММ-ДД");
                dateTest[i] = Date.valueOf(scanner.nextLine());
                preparedStatement.setDate(chetchik, dateTest[i]);
                chetchik++;
            }

            String[] examScore = new String[5];
            Date[] dateExams = new Date[5];

            for (int i = 0; i < 5; i++){
                System.out.println("введите оценку за экзамен");
                examScore[i] = scanner.nextLine();
                preparedStatement.setInt(chetchik, Integer.parseInt(examScore[i]));
                chetchik++;

                System.out.println("Введите дату " + (i+1) + " экзамена в таком формате ГГГГ-ММ-ДД");
                dateExams[i] = Date.valueOf(scanner.nextLine());
                preparedStatement.setDate(chetchik, dateExams[i]);
                chetchik++;
            }

            preparedStatement.execute();



        } catch (SQLException e) {
            throw new RuntimeException(e);
        }


    }
    //удаление студента из базы данных
    public static void deleteStudet(DBWorker worker){
        Scanner scanner = new Scanner(System.in);
        Function.printBase(worker);
        System.out.println("Введите id студента которого хотите удалить из базы");
        int delId = scanner.nextInt();

        PreparedStatement preparedStatement = null;
        String delete = new String("delete from users where id = ?");
        try {
            preparedStatement = worker.getConnection().prepareStatement(delete);
            preparedStatement.setInt(1,delId);
            preparedStatement.execute();

            System.out.println("Информацци о студенте успешна удалена");
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    //Корректировка информации о студенте
    public static void updateStudent(DBWorker worker){

        Scanner scanner = new Scanner(System.in);
        PreparedStatement preparedStatement = null;
        printBase(worker);
        try {
            System.out.println("Информацию о каком студенте хотите обновить? Введите id");
            String id = scanner.nextLine();

            System.out.println("Что хотите обновить и на какое значение. Пример ввода: FIO = 'Петров Николай Николаевич', dateOfBirh = '2004-09-14', exam 1 = 5");
            System.out.println("название категории вводить без кавычек, изменения все кроме exam[i] вводить в одинарных кавычках");
            String changes = scanner.nextLine();

            String update = new String("update users set " + changes + " where id = ?");

            preparedStatement = worker.getConnection().prepareStatement(update);
            preparedStatement.setInt(1,Integer.parseInt(id));
            preparedStatement.execute();
            preparedStatement.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public static void searchAge(DBWorker worker) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите возраст, больше или равно которого всем студентам");
        int age = Integer.parseInt(scanner.nextLine());
        String query = "select * from users;";
        java.util.Date date = new java.util.Date();//Актуальная дата

        //преобразуем актульная дату в localdate
        Instant instant = date.toInstant();
        ZonedDateTime zdt = instant.atZone(ZoneId.systemDefault());
        LocalDate actualDate = zdt.toLocalDate();
        LocalDate comparedDate = actualDate.minusYears(age);

        try {
            Statement statement = worker.getConnection().createStatement();
            ResultSet resultSet = statement.executeQuery(query);
            //вывод всей базы данных
            int countStudent = 0;
            while (resultSet.next()) {
                User user = new User();
                user.setDateOfBirth(resultSet.getDate(3));
                if (comparedDate.compareTo(user.getDateOfBirth().toLocalDate()) > 0){
                    user.setId(resultSet.getInt(1));
                    user.setFIO(resultSet.getString(2));
                    user.setTest1(resultSet.getString(4));
                    user.setDateTest1(resultSet.getDate(5));
                    user.setTest2(resultSet.getString(6));
                    user.setDateTest2(resultSet.getDate(7));
                    user.setTest3(resultSet.getString(8));
                    user.setDateTest3(resultSet.getDate(9));
                    user.setTest4(resultSet.getString(10));
                    user.setDateTest4(resultSet.getDate(11));
                    user.setTest5(resultSet.getString(12));
                    user.setDateTest5(resultSet.getDate(13));
                    user.setTest6(resultSet.getString(14));
                    user.setDateTest6(resultSet.getDate(15));
                    user.setTest7(resultSet.getString(16));
                    user.setDateTest7(resultSet.getDate(17));
                    user.setTest8(resultSet.getString(18));
                    user.setDateTest8(resultSet.getDate(19));
                    user.setTest9(resultSet.getString(20));
                    user.setDateTest9(resultSet.getDate(21));
                    user.setTest10(resultSet.getString(22));
                    user.setDateTest10(resultSet.getDate(23));
                    user.setExam1(resultSet.getInt(24));
                    user.setDateExam1(resultSet.getDate(25));
                    user.setExam2(resultSet.getInt(26));
                    user.setDateExam2(resultSet.getDate(27));
                    user.setExam3(resultSet.getInt(28));
                    user.setDateExam3(resultSet.getDate(29));
                    user.setExam4(resultSet.getInt(30));
                    user.setDateExam4(resultSet.getDate(31));
                    user.setExam5(resultSet.getInt(32));
                    user.setDateExam5(resultSet.getDate(33));

                    System.out.println(user);
                    countStudent++;
                }

            }
            if (countStudent == 0){
                System.out.println("студентов старше или с таким возрастом нет");
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public static void searchFIO(DBWorker worker){
        Scanner scanner = new Scanner(System.in);
        PreparedStatement preparedStatement = null;
        System.out.println("Введите фио студента информацию о котором хотите найти");
        String fio = scanner.nextLine();
        String select = "select * from users where FIO = ?";
        try {
            preparedStatement = worker.getConnection().prepareStatement(select);
            preparedStatement.setString(1,fio);
            ResultSet resultSet = preparedStatement.executeQuery();
            Function.printStudent(resultSet);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }





    public static void sortedABC(DBWorker worker) {
        String select = "select * from users order by FIO ASC ;";
        try {
            Statement statement = worker.getConnection().createStatement();
            ResultSet resultSet = statement.executeQuery(select);

            System.out.println("Отсортировання база данных по фамилиям студентов в алфавитном порпядке\n");
            printStudent(resultSet);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }

    public static void searchDebt(DBWorker worker) {
        System.out.println("Информация о студентах которые сдали сессию без долгов\n");
        String select = "select * from users where test1 = '+' and test2='+' and test3 = '+' and test4='+' and test5 = '+' and test6='+' and test7 = '+' and test8='+' and test9 = '+' and test10='+' and (exam1 = 5 or exam1 = 4 or exam1 = 3) and  (exam2 = 5 or exam2 = 4 or exam2 = 3) and (exam3 = 5 or exam3 = 4 or exam3 = 3) and (exam4 = 5 or exam4 = 4 or exam4 = 3) and (exam5 = 5 or exam5 = 4 or exam5 = 3)";
        try {
            Statement statement = worker.getConnection().createStatement();
            ResultSet resultSet = statement.executeQuery(select);
            Function.printStudent(resultSet);


        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }

    
}
