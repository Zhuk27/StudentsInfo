package data;

import java.sql.*;

public class Main {
    public static void main(String[] args) throws SQLException {

        DBWorker worker = new DBWorker();
        //Function.printBase(worker);
        //Function.addStudent(worker);
        //Function.deleteStudet(worker);
        //Function.updateStudent(worker);
        //Function.searchAge(worker);
        //Function.searchFIO(worker);
        //Function.sortedABC(worker);
        //Function.searchDebt(worker);



            //можно обновить удалить или создать нвоое
            //statement.execute("delete from users where name = 'Petr';");
            //можно оббновить показывает кол-во обновлённых
            //int i = statement.executeUpdate("update users set name = 'Kirill' where id>4;");

            //получени инфы из таблицы
            //ResultSet rezults = statement.executeQuery("select * from users;");
            //System.out.println(rezults.isBeforeFirst());
            //rezults.next();
            //while (!rezults.isAfterLast()){
            //    System.out.println(rezults.getRow());
            //    rezults.next();
            //}


            //добавление в пакет
            //statement.addBatch("insert into users(name, age, email) values('Gordey',19,'horosho@prosto.ru');");
            //statement.addBatch("insert into users(name, email) values('Margarita','jonSina@mail.ru');");
            //отправка пакета
            //statement.executeBatch();
            //отчистка пакета
            //statement.clearBatch();



    }


}
