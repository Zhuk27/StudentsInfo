package data;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class User {
    private int id;
    private String FIO;
    private Date dateOfBirth;
    private String test1;
    private Date dateTest1;
    private String test2;
    private Date dateTest2;
    private String test3;
    private Date dateTest3;
    private String test4;
    private Date dateTest4;
    private String test5;
    private Date dateTest5;
    private String test6;
    private Date dateTest6;
    private String test7;
    private Date dateTest7;
    private String test8;
    private Date dateTest8;
    private String test9;
    private Date dateTest9;
    private String test10;
    private Date dateTest10;
    private int exam1;
    private Date dateExam1;
    private int exam2;
    private Date dateExam2;
    private int exam3;
    private Date dateExam3;
    private int exam4;
    private Date dateExam4;
    private int exam5;
    private Date dateExam5;




    public User(){
    }

    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }

    public String getFIO() {
        return FIO;
    }

    public void setDateOfBirth(Date dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public void setFIO(String FIO) {
        this.FIO = FIO;
    }

    public String getTest1() {
        return test1;
    }
    public void setTest1(String test1) {
        this.test1 = test1;
    }

    public String getTest2() {
        return test2;
    }
    public void setTest2(String test2) {
        this.test2 = test2;
    }

    public String getTest3() {
        return test3;
    }
    public void setTest3(String test3) {
        this.test3 = test3;
    }

    public String getTest4() {
        return test4;
    }
    public void setTest4(String test4) {
        this.test4 = test4;
    }

    public String getTest5() {
        return test5;
    }
    public void setTest5(String test5) {
        this.test5 = test5;
    }

    public String getTest6() {
        return test6;
    }
    public void setTest6(String test6) {
        this.test6 = test6;
    }

    public String getTest7() {
        return test7;
    }
    public void setTest7(String test7) {
        this.test7 = test7;
    }

    public String getTest8() {
        return test8;
    }
    public void setTest8(String test8) {
        this.test8 = test8;
    }

    public String getTest9() {
        return test9;
    }
    public void setTest9(String test9) {
        this.test9 = test9;
    }

    public String getTest10() {
        return test10;
    }
    public void setTest10(String test10) {
        this.test10 = test10;
    }

    public int getExam1() {
        return exam1;
    }
    public void setExam1(int exam1) {
        this.exam1 = exam1;
    }


    public int getExam2() {
        return exam2;
    }
    public void setExam2(int exam2) {
        this.exam2 = exam2;
    }


    public int getExam3() {
        return exam3;
    }
    public void setExam3(int exam3) {
        this.exam3 = exam3;
    }

    public int getExam4() {
        return exam4;
    }
    public void setExam4(int exam4) {
        this.exam4 = exam4;
    }

    public int getExam5() {
        return exam5;
    }
    public void setExam5(int exam5) {
        this.exam5 = exam5;
    }

    public Date getDateOfBirth() {
        return dateOfBirth;
    }

    public Date getDateTest1() {
        return dateTest1;
    }

    public void setDateTest1(Date dateTest1) {
        this.dateTest1 = dateTest1;
    }

    public Date getDateTest2() {
        return dateTest2;
    }

    public void setDateTest2(Date dateTest2) {
        this.dateTest2 = dateTest2;
    }

    public Date getDateTest3() {
        return dateTest3;
    }

    public void setDateTest3(Date dateTest3) {
        this.dateTest3 = dateTest3;
    }

    public Date getDateTest4() {
        return dateTest4;
    }

    public void setDateTest4(Date dateTest4) {
        this.dateTest4 = dateTest4;
    }

    public Date getDateTest5() {
        return dateTest5;
    }

    public void setDateTest5(Date dateTest5) {
        this.dateTest5 = dateTest5;
    }

    public Date getDateTest6() {
        return dateTest6;
    }

    public void setDateTest6(Date dateTest6) {
        this.dateTest6 = dateTest6;
    }

    public Date getDateTest7() {
        return dateTest7;
    }

    public void setDateTest7(Date dateTest7) {
        this.dateTest7 = dateTest7;
    }

    public Date getDateTest8() {
        return dateTest8;
    }

    public void setDateTest8(Date dateTest8) {
        this.dateTest8 = dateTest8;
    }

    public Date getDateTest9() {
        return dateTest9;
    }

    public void setDateTest9(Date dateTest9) {
        this.dateTest9 = dateTest9;
    }

    public Date getDateTest10() {
        return dateTest10;
    }

    public void setDateTest10(Date dateTest10) {
        this.dateTest10 = dateTest10;
    }

    public Date getDateExam1() {
        return dateExam1;
    }

    public void setDateExam1(Date dateExam1) {
        this.dateExam1 = dateExam1;
    }

    public Date getDateExam2() {
        return dateExam2;
    }

    public void setDateExam2(Date dateExam2) {
        this.dateExam2 = dateExam2;
    }

    public Date getDateExam3() {
        return dateExam3;
    }

    public void setDateExam3(Date dateExam3) {
        this.dateExam3 = dateExam3;
    }

    public Date getDateExam4() {
        return dateExam4;
    }

    public void setDateExam4(Date dateExam4) {
        this.dateExam4 = dateExam4;
    }

    public Date getDateExam5() {
        return dateExam5;
    }

    public void setDateExam5(Date dateExam5) {
        this.dateExam5 = dateExam5;
    }

    @Override
    public String toString() {
        return "Student{" +
                 id +
                ", FIO: " + FIO  +
                ", date of birth: " + dateOfBirth +
                ", test1: " + test1 +
                ", dateTest1: " + dateTest1 +
                ", test2: " + test2 +
                ", dateTest2: " + dateTest2 +
                ", test3: " + test3 +
                ", dateTest3: " + dateTest3 +
                ", test4: " + test4 +
                ", dateTest4: " + dateTest4 +
                ", test5: " + test5 +
                ", dateTest5: " + dateTest5 +
                ", test6: " + test6 +
                ", dateTest6: " + dateTest6 +
                ", test7: " + test7 +
                ", dateTest7: " + dateTest7 +
                ", test8: " + test8 +
                ", dateTest8: " + dateTest8 +
                ", test9: " + test9 +
                ", dateTest9: " + dateTest9 +
                ", test10: " + test10 +
                ", dateTest10: " + dateTest10 +
                ", exam1: " + exam1 +
                ", dateExam1: " + dateExam1 +
                ", exam2: " + exam2 +
                ", dateExam2:" + dateExam2 +
                ", exam3: " + exam3 +
                ", dateExam3: " + dateExam3 +
                ", exam4: " + exam4 +
                ", dateExam4: " + dateExam4 +
                ", exam5: " + exam5 +
                ", dateExam5: " + dateExam5 +
                '}';
    }
}
